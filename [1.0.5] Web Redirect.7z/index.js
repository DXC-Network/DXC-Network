WebRedirect = require("./WebRedirect.js");

WebRedirect.WebRedirect();
