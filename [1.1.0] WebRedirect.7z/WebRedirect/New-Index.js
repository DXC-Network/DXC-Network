/// New-Index.js calls for New-WebRedirect.js

WebRedirect = require("./New-WebRedirect.js");
WebRedirect.WebRedirect();
